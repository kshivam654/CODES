# Whatsapp Clone
Whatsapp android clone using Firebase for realtime chat and notifications.

<a href="/screenshots/device-2017-06-29-164146.png"><img src="/screenshots/device-2017-06-29-164146.png" width="30%"/></a> <a href="/screenshots/device-2017-06-29-165918.png"><img src="/screenshots/device-2017-06-29-165918.png" width="30%"/></a> <a href="/screenshots/device-2017-06-29-164627.png"><img src="/screenshots/device-2017-06-29-164627.png" width="30%"/></a>
<a href="/screenshots/device-2017-06-29-172154.png"><img src="/screenshots/device-2017-06-29-172154.png" width="30%"/></a>

